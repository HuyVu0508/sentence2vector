Please look for the dataset from the github link provided in the README.txt.
The dataset is too heavy to be included here.
Thank you.
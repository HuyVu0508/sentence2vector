# Copyright 2017 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

import tensorflow as tf
import numpy as np
import collections

from ops import input_ops

FLAGS = tf.flags.FLAGS

def read_vocab_embs(vocabulary_file, embedding_matrix_file):
  tf.logging.info("Reading vocabulary from %s", vocabulary_file)
  with tf.gfile.GFile(vocabulary_file, mode="r") as f:
    lines = list(f.readlines())
  vocab = [line.decode("utf-8").strip() for line in lines]
  
  with open(embedding_matrix_file, "r") as f:
    embedding_matrix = np.load(f)
  tf.logging.info("Loaded embedding matrix with shape %s",
                  embedding_matrix.shape)
  word_embedding_dict = collections.OrderedDict(
      zip(vocab, embedding_matrix))
  return word_embedding_dict

def read_vocab(vocabulary_file):
  tf.logging.info("Reading vocabulary from %s", vocabulary_file)
  with tf.gfile.GFile(vocabulary_file, mode="r") as f:
    lines = list(f.readlines())
  reverse_vocab = [line.strip() for line in lines]
  tf.logging.info("Loaded vocabulary with %d words.", len(reverse_vocab))
 
  #tf.logging.info("Loading embedding matrix from %s", embedding_matrix_file)
  # Note: tf.gfile.GFile doesn't work here because np.load() calls f.seek()
  # with 3 arguments.
  word_embedding_dict = collections.OrderedDict(
      zip(reverse_vocab, range(len(reverse_vocab))))
  return word_embedding_dict
    

class s2v(object):
  """Skip-thoughts model."""

  def __init__(self, config, mode="train", input_reader=None, input_queue=None):
    """Basic setup. The actual TensorFlow graph is constructed in build().

    Args:
      config: Object containing configuration parameters.
      mode: "train", "eval" or "encode".
      input_reader: Subclass of tf.ReaderBase for reading the input serialized
        tf.Example protocol buffers. Defaults to TFRecordReader.

    Raises:
      ValueError: If mode is invalid.
    """
    if mode not in ["train", "eval", "encode"]:
      raise ValueError("Unrecognized mode: %s" % mode)

    self.config = config
    self.mode = mode
    self.reader_word = input_reader if input_reader else tf.TFRecordReader()
    self.reader_POS = input_reader if input_reader else tf.TFRecordReader()
    self.input_queue = input_queue

    # Initializer used for non-recurrent weights.
    self.uniform_initializer = tf.random_uniform_initializer(
        minval=-FLAGS.uniform_init_scale,
        maxval=FLAGS.uniform_init_scale)

    # Input sentences represented as sequences of word ids. "encode" is the
    # source sentence, "decode_pre" is the previous sentence and "decode_post"
    # is the next sentence.
    # Each is an int64 Tensor with  shape [batch_size, padded_length].
    self.encode_ids = None

    # Boolean masks distinguishing real words (1) from padded words (0).
    # Each is an int32 Tensor with shape [batch_size, padded_length].
    self.encode_mask = None

    # Input sentences represented as sequences of word embeddings.
    # Each is a float32 Tensor with shape [batch_size, padded_length, emb_dim].
    self.encode_emb = None

    # The output from the sentence encoder.
    # A float32 Tensor with shape [batch_size, num_gru_units].
    self.thought_vectors = None

    # The total loss to optimize.
    self.total_loss = None


  def build_inputs(self):

    if self.mode == "encode":
      encode_ids = tf.placeholder(tf.int64, (None, None), name="encode_ids")
      encode_mask = tf.placeholder(tf.int8, (None, None), name="encode_mask")
      encode_labels = tf.placeholder(tf.int64, (None, None), name="encode_labels")
    else:
      # Prefetch serialized tf.Example protos.
      input_queue_word = input_ops.prefetch_input_data(
          self.reader_word,
          FLAGS.input_file_pattern_word,
          shuffle=FLAGS.shuffle_input_data,
          capacity=FLAGS.input_queue_capacity,
          num_reader_threads=FLAGS.num_input_reader_threads)
      # Deserialize a batch.
      serialized = input_queue_word.dequeue_many(FLAGS.batch_size)
      encode_word = input_ops.parse_example_batch(serialized)
      
      # Prefetch serialized tf.Example protos.
      input_queue_POS = input_ops.prefetch_input_data(
          self.reader_POS,
          FLAGS.input_file_pattern_POS,
          shuffle=FLAGS.shuffle_input_data,
          capacity=FLAGS.input_queue_capacity,
          num_reader_threads=FLAGS.num_input_reader_threads)
      # Deserialize a batch.
      serialized = input_queue_POS.dequeue_many(FLAGS.batch_size)
      encode_POS = input_ops.parse_example_batch(serialized)      

      encode_ids = encode_word.ids
      encode_mask = encode_word.mask
      encode_labels = tf.cast(encode_POS.ids, tf.int32)
      encode_mask_labels = encode_POS.mask
      
#      encode_ids = tf.Print(encode_ids,[encode_ids[1,:30]], summarize=30)
#      encode_labels = tf.Print(encode_labels,[encode_labels[1,:30]], summarize=30)
#      encode_mask = tf.Print(encode_mask,[encode_mask[1,:30]], summarize=10)
#      words_length = tf.reduce_sum(encode_mask[1,:30])
#      words_length = tf.Print(words_length,[words_length])
#      POSs_length = tf.reduce_sum(encode_mask_labels[1,:30])
#      POSs_length = tf.Print(POSs_length,[POSs_length])
      
    self.encode_ids = encode_ids
    self.encode_mask = encode_mask 
    self.encode_labels = encode_labels
    
  def build_word_embeddings(self):

    rand_init = self.uniform_initializer
    self.word_embeddings = []
    self.encode_emb = []
    self.init = None
    for v in self.config.vocab_configs:

      if v.mode == 'fixed':
        if self.mode == "train":
          word_emb = tf.get_variable(
              name=v.name,
              shape=[v.size, v.dim],
              trainable=False)
          embedding_placeholder = tf.placeholder(
              tf.float32, [v.size, v.dim])
          embedding_init = word_emb.assign(embedding_placeholder)

          rand = np.random.rand(1, v.dim)
          word_vecs = np.load(v.embs_file)
          load_vocab_size = word_vecs.shape[0]
          assert(load_vocab_size == v.size - 1)
          word_init = np.concatenate((rand, word_vecs), axis=0)
          self.init = (embedding_init, embedding_placeholder, word_init)
        
        else:
          word_emb = tf.get_variable(
              name=v.name,
              shape=[v.size, v.dim])

        encode_emb = tf.nn.embedding_lookup(word_emb, self.encode_ids)
        self.word_emb = word_emb
        self.encode_emb.extend([encode_emb, encode_emb])

      if v.mode == 'trained':
        for inout in ["", "_out"]:
          word_emb = tf.get_variable(
              name=v.name + inout,
              shape=[v.size, v.dim],
              initializer=rand_init)
          if self.mode == 'train':
            self.word_embeddings.append(word_emb)

          encode_emb = tf.nn.embedding_lookup(word_emb, self.encode_ids)
          self.encode_emb.append(encode_emb)

      if v.mode == 'expand':
        for inout in ["", "_out"]:
          encode_emb = tf.placeholder(tf.float32, (
              None, None, v.dim), v.name + inout)
          self.encode_emb.append(encode_emb)
          word_emb_dict = read_vocab_embs(v.vocab_file + inout + ".txt",
              v.embs_file + inout + ".npy")
          self.word_embeddings.append(word_emb_dict)

      if v.mode != 'expand' and self.mode == 'encode':
        word_emb_dict = read_vocab(v.vocab_file)
        self.word_embeddings.extend([word_emb_dict, word_emb_dict])

  def _initialize_cell(self, num_units, cell_type="GRU"):
    if cell_type == "GRU":
      return tf.contrib.rnn.GRUCell(num_units=num_units)
    elif cell_type == "LSTM":
      return tf.contrib.rnn.LSTMCell(num_units=num_units)
    else:
      raise ValueError("Invalid cell type")

  def bow(self, word_embs, mask):
    mask_f = tf.expand_dims(tf.cast(mask, tf.float32), -1)
    word_embs_mask = word_embs * mask_f
    bow = tf.reduce_sum(word_embs_mask, axis=1)
    return bow

  def rnn(self, word_embs, mask, scope, encoder_dim, cell_type="GRU"):

    length = tf.to_int32(tf.reduce_sum(mask, 1), name="length")

    if self.config.bidir:
      if encoder_dim % 2:
        raise ValueError(
            "encoder_dim must be even when using a bidirectional encoder.")
      num_units = encoder_dim // 2
      cell_fw = self._initialize_cell(num_units, cell_type=cell_type)
      cell_bw = self._initialize_cell(num_units, cell_type=cell_type)
      outputs, states = tf.nn.bidirectional_dynamic_rnn(
          cell_fw=cell_fw,
          cell_bw=cell_bw,
          inputs=word_embs,
          sequence_length=length,
          dtype=tf.float32,
          scope=scope)
      if cell_type == "LSTM":
        states = [states[0][1], states[1][1]]
      state = tf.concat(states, 1)
    else:
      cell = self._initialize_cell(encoder_dim, cell_type=cell_type)
      outputs, state = tf.nn.dynamic_rnn(
          cell=cell,
          inputs=word_embs,
          sequence_length=length,
          dtype=tf.float32,
          scope=scope)
      if cell_type == "LSTM":
        state = state[1]
    return state


  def build_encoder(self):
    """Builds the sentence encoder.

    Inputs:
      self.encode_emb
      self.encode_mask

    Outputs:
      self.thought_vectors

    Raises:
      ValueError: if config.bidirectional_encoder is True and config.encoder_dim
        is odd.
    """
    names = ["","_out"]
    self.thought_vectors = []
    print(self.config.encoder)
    for i in range(2):
      with tf.variable_scope("encoder" + names[i]) as scope:
        
        if self.config.encoder == "gru":
          sent_rep = self.rnn(self.encode_emb[i], self.encode_mask, scope, self.config.encoder_dim, cell_type="GRU")
        elif self.config.encoder == "lstm":
          sent_rep = self.rnn(self.encode_emb[i], self.encode_mask, scope, self.config.encoder_dim, cell_type="LSTM")
        elif self.config.encoder == 'bow':
          sent_rep = self.bow(self.encode_emb[i], self.encode_mask)
        else:
          raise ValueError("Invalid encoder")

        thought_vectors = tf.identity(sent_rep, name="thought_vectors")
        self.thought_vectors.append(thought_vectors)


  def build_grammar_output(self):
    """ Build the output of graph, including: score for semantic learning task + prediction output for grammatical tasks
    
    Input:
        self.thought_vectors
    Output:
        self.semantic_scores_prediction
        self.gram_t1_prediction
        self.gram_t2_prediction
    
    """

    
    ### Predictions for grammatical learning tasks    
    # Type-1 grammatical learning task - position
    # Define constant values
    rnn_size = self.config.encoder_dim
    num_layers = 1   
    classes_size = 48   # 47 classes + 1 <s> token   
    start_of_sequence_id = 47
    end_of_sequence_id = 0    # <UNK> token
    dec_embed_matrix = tf.eye(classes_size)
    target_sequence_length = tf.to_int32(tf.reduce_sum(self.encode_mask, 1))
    assigned_max_sequence_length = 30
    batch_size = tf.cast(tf.shape(self.thought_vectors[0])[0], tf.int32)
    
#    # Build nodes
#    # Output layer
#    output_layer = tf.layers.Dense(units = classes_size)
#    # LSTM
#    dec_cell = tf.contrib.rnn.BasicLSTMCell(rnn_size, state_is_tuple=True)
#    if ((self.mode == "train") | (self.mode == "eval")):
#        label_shift_1 = tf.concat([tf.fill([batch_size, 1], start_of_sequence_id), self.encode_labels[:, 0:-1]], axis = 1)
#        dec_embed_input = tf.nn.embedding_lookup(dec_embed_matrix, label_shift_1)
#        helper = tf.contrib.seq2seq.TrainingHelper(dec_embed_input, target_sequence_length)
#    elif (self.mode == "encode"):
#        helper = tf.contrib.seq2seq.GreedyEmbeddingHelper(dec_embed_matrix, tf.fill([batch_size, 1], start_of_sequence_id), end_of_sequence_id)        
#
#    state_c = self.thought_vectors[0]
#    state_h = tf.zeros(tf.shape(state_c))
#    encoder_state = tf.contrib.rnn.LSTMStateTuple(state_c, state_h) 
#   
#    decoder = tf.contrib.seq2seq.BasicDecoder(dec_cell, helper, encoder_state, output_layer) 
#    decoder_output = tf.contrib.seq2seq.dynamic_decode(decoder, impute_finished=True, maximum_iterations=assigned_max_sequence_length)        
#    self.grammar_prediction = decoder_output[0].rnn_output
#    self.grammar_prediction = tf.Print(self.grammar_prediction, [tf.shape(self.grammar_prediction)], message = "Size of self.grammar_prediction: ")


    # Build nodes
    # LSTM
    dec_cell = tf.contrib.rnn.BasicLSTMCell(rnn_size, state_is_tuple=True)
    if ((self.mode == "train") | (self.mode == "eval")):
        label_shift_1 = tf.concat([tf.fill([batch_size, 1], start_of_sequence_id), self.encode_labels[:, 0:-1]], axis = 1)
        dec_embed_input = tf.nn.embedding_lookup(dec_embed_matrix, label_shift_1)
        helper = tf.contrib.seq2seq.TrainingHelper(dec_embed_input, target_sequence_length)
    elif (self.mode == "encode"):
        helper = tf.contrib.seq2seq.GreedyEmbeddingHelper(dec_embed_matrix, tf.fill([batch_size, 1], start_of_sequence_id), end_of_sequence_id)        

    state_c = self.thought_vectors[0]
    state_h = tf.zeros(tf.shape(state_c))
    encoder_state = tf.contrib.rnn.LSTMStateTuple(state_c, state_h) 
   
    decoder = tf.contrib.seq2seq.BasicDecoder(dec_cell, helper, encoder_state) 
    decoder_output = tf.contrib.seq2seq.dynamic_decode(decoder, impute_finished=True, maximum_iterations=assigned_max_sequence_length)        
    # Dense layer
    decoder_output = tf.layers.dense(inputs = decoder_output[0].rnn_output, units = classes_size)    
    self.grammar_prediction = decoder_output



    # Testing output
    # Grammatical output
#    test_var = tf.argmax(self.grammar_prediction, axis = -1)
#    test_var = tf.Print(test_var,[test_var[1,:]], message = "Predictions :", summarize = 10)
#    test_var = self.grammar_prediction
#    test_var = tf.Print(test_var, [self.grammar_prediction[0,1:10]], message = "Logits 0 :", summarize = 30)
#    test_var = tf.Print(test_var, [self.grammar_prediction[1,1:10]], message = "Logits 1 :", summarize = 30)
#    test_var = tf.Print(test_var, [self.grammar_prediction[2,1:10]], message = "Logits 2 :", summarize = 30)
#    test_var = tf.Print(test_var, [self.grammar_prediction[3,1:10]], message = "Logits 3 :", summarize = 30)
#    test_var = tf.Print(test_var, [self.grammar_prediction[4,1:10]], message = "Logits 4 :", summarize = 30)
#    test_var = tf.argmax(test_var, axis = -1)
#    self.encode_labels = self.encode_labels + 0*tf.cast(test_var,tf.int32)
#    self.encode_labels = tf.Print(self.encode_labels,[self.encode_labels[1,:]], message = "Labels :", summarize = 10)

    
    


  def build_loss(self):
    """Builds the loss Tensor.

    Outputs:
      self.total_loss
    """

    all_sen_embs = self.thought_vectors
  
    
    # Semantic Losses
    if FLAGS.dropout:
      mask_shp = [1, self.config.encoder_dim]
      bin_mask = tf.random_uniform(mask_shp) > FLAGS.dropout_rate
      bin_mask = tf.where(bin_mask, tf.ones(mask_shp), tf.zeros(mask_shp))
      src = all_sen_embs[0] * bin_mask
      dst = all_sen_embs[1] * bin_mask
      scores = tf.matmul(src, dst, transpose_b=True)
    else:
      scores = tf.matmul(all_sen_embs[0], all_sen_embs[1], transpose_b=True)
    # Ignore source sentence
    scores = tf.matrix_set_diag(scores, np.zeros(FLAGS.batch_size))
    # Targets
    targets_np = np.zeros((FLAGS.batch_size, FLAGS.batch_size))
    ctxt_sent_pos = list(range(-FLAGS.context_size, FLAGS.context_size + 1))
    ctxt_sent_pos.remove(0)
    for ctxt_pos in ctxt_sent_pos:
      targets_np += np.eye(FLAGS.batch_size, k=ctxt_pos)
    targets_np_sum = np.sum(targets_np, axis=1, keepdims=True)
    targets_np = targets_np/targets_np_sum
    targets = tf.constant(targets_np, dtype=tf.float32)
    # Forward and backward scores    
    f_scores = scores[:-1] 
    b_scores = scores[1:]        
#    # Testing output
#    # Semantic output
#    targets = tf.Print(targets,[targets[2,0:5]], message = "Target labels: ", summarize = 5)
#    targets = tf.Print(targets,[self.encode_ids[0,0:10]], message = "Candidate sentences 0: ", summarize = 10)
#    targets = tf.Print(targets,[self.encode_ids[1,0:10]], message = "Candidate sentences 1: ", summarize = 10)
#    targets = tf.Print(targets,[self.encode_ids[2,0:10]], message = "Candidate sentences 2: ", summarize = 10)
#    targets = tf.Print(targets,[self.encode_ids[3,0:10]], message = "Candidate sentences 3: ", summarize = 10)
#    targets = tf.Print(targets,[self.encode_ids[4,0:10]], message = "Candidate sentences 4: ", summarize = 10)
    # Losss
    semantic_losses = tf.nn.softmax_cross_entropy_with_logits(
        labels=targets, logits=scores)
  
    
    # Grammatic Losses
    target_sequence_length = tf.to_int32(tf.reduce_sum(self.encode_mask, 1))
    weights = tf.cast(tf.sequence_mask(target_sequence_length, 30),tf.float32)
    grammatic_losses = tf.contrib.seq2seq.sequence_loss(logits = self.grammar_prediction, 
                                                        targets = self.encode_labels, 
                                                        weights = weights,
                                                        average_across_timesteps = True, 
                                                        average_across_batch=False)
    # Print out losses
    semantic_losses = tf.Print(semantic_losses, [tf.reduce_mean(semantic_losses)], message = "Semantic_losses: ")
    grammatic_losses = tf.Print(grammatic_losses,[tf.reduce_mean(grammatic_losses)], message = "Grammatic_losses: ")
    
    
    
    # Averaging loss across batch
    if FLAGS.model_version == 0:    # Running original model
        losses = semantic_losses
    elif FLAGS.model_version == 1:  # Running improved model  
        losses = semantic_losses + grammatic_losses
    loss = tf.reduce_mean(losses)



    tf.summary.scalar("losses/ent_loss", loss)
    self.total_loss = loss

    if self.mode == "eval":
      f_max = tf.to_int64(tf.argmax(f_scores, axis=1))
      b_max = tf.to_int64(tf.argmax(b_scores, axis=1))

      targets = range(FLAGS.batch_size - 1)
      targets = tf.constant(targets, dtype=tf.int64)
      fwd_targets = targets + 1

      names_to_values, names_to_updates = tf.contrib.slim.metrics.aggregate_metric_map({
        "Acc/Fwd Acc": tf.contrib.slim.metrics.streaming_accuracy(f_max, fwd_targets), 
        "Acc/Bwd Acc": tf.contrib.slim.metrics.streaming_accuracy(b_max, targets)
      })

      for name, value in names_to_values.iteritems():
        tf.summary.scalar(name, value)

      self.eval_op = names_to_updates.values()

  def build(self):
    """Creates all ops for training, evaluation or encoding."""
    self.build_inputs()
    self.build_word_embeddings()
    self.build_encoder()
    self.build_grammar_output()    
    self.build_loss()

  def build_enc(self):
    """Creates all ops for training, evaluation or encoding."""
    self.build_inputs()
    self.build_word_embeddings()
    self.build_encoder()
